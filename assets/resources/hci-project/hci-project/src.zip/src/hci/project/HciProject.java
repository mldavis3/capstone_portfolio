/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hci.project;


import java.util.Scanner;
import java.util.Arrays;

public class HciProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int SIZE;
        
        
        Scanner reader = new Scanner(System.in);
    
        System.out.print("Enter amount of Subcontractors: ");
        SIZE = reader.nextInt();
        reader.nextLine();
        
        SubContractor subs[];
        subs = new SubContractor[SIZE];
        
        for (int i = 0; i < SIZE; i++){
            SubContractor a;
            a = new SubContractor();
            
            System.out.print("Enter Subcontractor Name: ");
            a.setName(reader.nextLine());
            System.out.print("Enter Subcontractor Company: ");
            a.setCompany(reader.nextLine());
            System.out.print("Enter Subcontractor Hourly Rate: ");
            a.setHourlyRate(reader.nextLine());
            System.out.print("Enter Subcontractor Phone Number: ");
            a.setPhoneNumber(reader.nextLine());
            
            System.out.println(a.getName());
            System.out.println(a.getCompany());
            System.out.println(a.getHourlyRate());
            System.out.println(a.getPhoneNumber());
            
        }  
    }
    
}
