/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hci.project;

    import java.util.Scanner;
/**
 *
 * @author Michael
 */
public class SubContractor {
    public String name, company, hourlyRate, phoneNumber;
    
    Scanner input = new Scanner(System.in);
    
    public void setName(String newName){
        //System.out.print("Enter Subcontractor Name: ");
        newName = input.nextLine();
        name = newName;
    }
    
    public String getName(){
        return name;
    }
    
    public void setCompany(String newCompany){
        //System.out.print("Enter Subcontractor Company");
        newCompany = input.nextLine();
        company = newCompany;
    }
    
    public String getCompany(){
        return company;
    }
    
    public void setHourlyRate(String newHourlyRate){
        //System.out.print("Enter Subcontractor Hourly Rate: ");
        newHourlyRate = input.nextLine();
        hourlyRate = newHourlyRate;
    }
    
    public String getHourlyRate(){
        return hourlyRate;
    }
    
    public void setPhoneNumber(String newPhoneNumber){
        //System.out.print("Enter Subcontractor Phone Number: ");
        newPhoneNumber = input.nextLine();
        phoneNumber = newPhoneNumber;
    }
    
    public String getPhoneNumber(){
        return phoneNumber;         
    }
}

